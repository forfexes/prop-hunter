PROP HUNTER — CURRENT ALL FILES V10
===================================

Dieses Paket enthält alle aktuellen Dateien, die wir gerade brauchen.

AKTUELLE ERSATZDATEIEN:
- prophunter.py
- prop_hunter_scoring.py
- prop_hunter_scraper.py
- requirements.txt
- .github/workflows/prophunter.yml

NEUE V10 / LEARNING MACHINE DATEIEN:
- prop_hunter_database_v10.sql
- prop_hunter_league_config.py
- prop_hunter_rules.py
- prop_hunter_leg_builder.py
- prop_hunter_learning.py
- prop_hunter_history_scraper.py

REIHENFOLGE:
1. prop_hunter_database_v10.sql in Supabase ausführen.
2. Alle Dateien ins GitHub Repo hochladen/ersetzen.
3. Workflow starten.
4. Log prüfen.

ERWARTETER LOG:
- PROP HUNTER DATA+ SCRAPER ONLY
- DATA+ scraper done
- PROP HUNTER V10 HISTORY SCRAPER
- history scraper done
- PROP HUNTER v4 DATA+ TEAM-SAFE
- DATA+ cache found
- DATA+ enrichment applied
- Telegram OK

WICHTIG:
prophunter.py ist aktuell die funktionierende TEAM-SAFE Version.
Die V10-Dateien rules/leg_builder/learning/history sind der neue Unterbau.
Als nächsten Schritt integrieren wir rules + leg_builder direkt in prophunter.py,
damit der Bot echte 1-5 Legs, HR/TD/DD/Triple-Double/Cross-Sport Builder baut.
