
-- PROP HUNTER FINAL COVERAGE SQL
-- ==============================

create table if not exists prop_hunter_prop_snapshots (
  id bigserial primary key,
  snapshot_id text unique,
  source text,
  sport text,
  league text,
  source_sport_key text,
  source_event_id text,
  game_id text,
  commence_time timestamptz,
  home_team text,
  away_team text,
  player_name text,
  normalized_name text,
  market text,
  market_key text,
  line numeric,
  odds_decimal numeric,
  bookmaker text,
  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);

create table if not exists prop_hunter_results (
  id bigserial primary key,
  result_id text unique,
  pick_id text,
  sport text,
  league text,
  player_name text,
  normalized_name text,
  market text,
  stat_key text,
  line numeric,
  side text,
  actual_value jsonb,
  result text,
  game_id text,
  settled_at timestamptz default now(),
  pick_raw jsonb default '{}'::jsonb,
  result_raw jsonb default '{}'::jsonb
);

create table if not exists prop_hunter_rule_performance (
  id bigserial primary key,
  performance_id text unique,
  group_type text,
  group_key text,
  bets int default 0,
  wins int default 0,
  losses int default 0,
  pushes int default 0,
  profit numeric default 0,
  stake numeric default 0,
  roi numeric default 0,
  hit_rate numeric default 0,
  learning_weight numeric default 1,
  updated_at timestamptz default now()
);

alter table prop_hunter_prop_snapshots add column if not exists snapshot_id text unique;
alter table prop_hunter_prop_snapshots add column if not exists source text;
alter table prop_hunter_prop_snapshots add column if not exists sport text;
alter table prop_hunter_prop_snapshots add column if not exists league text;
alter table prop_hunter_prop_snapshots add column if not exists source_sport_key text;
alter table prop_hunter_prop_snapshots add column if not exists source_event_id text;
alter table prop_hunter_prop_snapshots add column if not exists game_id text;
alter table prop_hunter_prop_snapshots add column if not exists commence_time timestamptz;
alter table prop_hunter_prop_snapshots add column if not exists home_team text;
alter table prop_hunter_prop_snapshots add column if not exists away_team text;
alter table prop_hunter_prop_snapshots add column if not exists player_name text;
alter table prop_hunter_prop_snapshots add column if not exists normalized_name text;
alter table prop_hunter_prop_snapshots add column if not exists market text;
alter table prop_hunter_prop_snapshots add column if not exists market_key text;
alter table prop_hunter_prop_snapshots add column if not exists line numeric;
alter table prop_hunter_prop_snapshots add column if not exists odds_decimal numeric;
alter table prop_hunter_prop_snapshots add column if not exists bookmaker text;
alter table prop_hunter_prop_snapshots add column if not exists raw jsonb default '{}'::jsonb;
alter table prop_hunter_prop_snapshots add column if not exists created_at timestamptz default now();

alter table prop_hunter_results add column if not exists result_id text unique;
alter table prop_hunter_results add column if not exists pick_id text;
alter table prop_hunter_results add column if not exists sport text;
alter table prop_hunter_results add column if not exists league text;
alter table prop_hunter_results add column if not exists player_name text;
alter table prop_hunter_results add column if not exists normalized_name text;
alter table prop_hunter_results add column if not exists market text;
alter table prop_hunter_results add column if not exists stat_key text;
alter table prop_hunter_results add column if not exists line numeric;
alter table prop_hunter_results add column if not exists side text;
alter table prop_hunter_results add column if not exists actual_value jsonb;
alter table prop_hunter_results add column if not exists result text;
alter table prop_hunter_results add column if not exists game_id text;
alter table prop_hunter_results add column if not exists settled_at timestamptz default now();
alter table prop_hunter_results add column if not exists pick_raw jsonb default '{}'::jsonb;
alter table prop_hunter_results add column if not exists result_raw jsonb default '{}'::jsonb;

alter table prop_hunter_rule_performance add column if not exists performance_id text unique;
alter table prop_hunter_rule_performance add column if not exists group_type text;
alter table prop_hunter_rule_performance add column if not exists group_key text;
alter table prop_hunter_rule_performance add column if not exists bets int default 0;
alter table prop_hunter_rule_performance add column if not exists wins int default 0;
alter table prop_hunter_rule_performance add column if not exists losses int default 0;
alter table prop_hunter_rule_performance add column if not exists pushes int default 0;
alter table prop_hunter_rule_performance add column if not exists profit numeric default 0;
alter table prop_hunter_rule_performance add column if not exists stake numeric default 0;
alter table prop_hunter_rule_performance add column if not exists roi numeric default 0;
alter table prop_hunter_rule_performance add column if not exists hit_rate numeric default 0;
alter table prop_hunter_rule_performance add column if not exists learning_weight numeric default 1;
alter table prop_hunter_rule_performance add column if not exists updated_at timestamptz default now();

-- columns for player result tables
alter table prop_hunter_player_gamelogs add column if not exists source text;
alter table prop_hunter_player_gamelogs add column if not exists source_game_id text;
alter table prop_hunter_player_gamelogs add column if not exists week text;
alter table prop_hunter_player_gamelogs add column if not exists points numeric;
alter table prop_hunter_player_gamelogs add column if not exists rebounds numeric;
alter table prop_hunter_player_gamelogs add column if not exists assists numeric;
alter table prop_hunter_player_gamelogs add column if not exists pra numeric;
alter table prop_hunter_player_gamelogs add column if not exists ra numeric;
alter table prop_hunter_player_gamelogs add column if not exists threes_made numeric;
alter table prop_hunter_player_gamelogs add column if not exists steals numeric;
alter table prop_hunter_player_gamelogs add column if not exists blocks numeric;
alter table prop_hunter_player_gamelogs add column if not exists turnovers numeric;
alter table prop_hunter_player_gamelogs add column if not exists double_double boolean;
alter table prop_hunter_player_gamelogs add column if not exists triple_double boolean;
alter table prop_hunter_player_gamelogs add column if not exists receptions numeric;
alter table prop_hunter_player_gamelogs add column if not exists receiving_yards numeric;
alter table prop_hunter_player_gamelogs add column if not exists rushing_yards numeric;
alter table prop_hunter_player_gamelogs add column if not exists rush_attempts numeric;
alter table prop_hunter_player_gamelogs add column if not exists passing_yards numeric;
alter table prop_hunter_player_gamelogs add column if not exists passing_tds numeric;
alter table prop_hunter_player_gamelogs add column if not exists interceptions numeric;
alter table prop_hunter_player_gamelogs add column if not exists touchdowns numeric;
alter table prop_hunter_player_gamelogs add column if not exists anytime_td boolean;
alter table prop_hunter_player_gamelogs add column if not exists two_plus_td boolean;
alter table prop_hunter_player_gamelogs add column if not exists targets numeric;
alter table prop_hunter_player_gamelogs add column if not exists hits numeric;
alter table prop_hunter_player_gamelogs add column if not exists total_bases numeric;
alter table prop_hunter_player_gamelogs add column if not exists home_runs numeric;
alter table prop_hunter_player_gamelogs add column if not exists rbi numeric;
alter table prop_hunter_player_gamelogs add column if not exists runs numeric;
alter table prop_hunter_player_gamelogs add column if not exists strikeouts_batter numeric;
alter table prop_hunter_player_gamelogs add column if not exists walks_batter numeric;
alter table prop_hunter_player_gamelogs add column if not exists stolen_bases numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_strikeouts numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_innings numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_hits_allowed numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_earned_runs numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_walks numeric;
alter table prop_hunter_player_gamelogs add column if not exists pitcher_home_runs_allowed numeric;
alter table prop_hunter_player_gamelogs add column if not exists raw jsonb default '{}'::jsonb;

create index if not exists idx_ph_snapshots_player on prop_hunter_prop_snapshots(normalized_name);
create index if not exists idx_ph_snapshots_market on prop_hunter_prop_snapshots(market_key);
create index if not exists idx_ph_snapshots_source on prop_hunter_prop_snapshots(source);
create index if not exists idx_ph_results_pick on prop_hunter_results(pick_id);
create index if not exists idx_ph_results_result on prop_hunter_results(result);
create index if not exists idx_ph_perf_group on prop_hunter_rule_performance(group_type, group_key);

alter table prop_hunter_prop_snapshots disable row level security;
alter table prop_hunter_results disable row level security;
alter table prop_hunter_rule_performance disable row level security;
