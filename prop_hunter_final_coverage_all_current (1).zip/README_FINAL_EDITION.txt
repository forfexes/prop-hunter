PROP HUNTER FINAL EDITION
=========================
Final-Source-Edition: NBA/WNBA/NFL/MLB + internationale Ligen vorbereitet.

Neue/ersetzte Dateien:
- prop_hunter_source_registry.py
- prop_hunter_backfill_universal.py
- prop_hunter_database_final.sql
- requirements.txt
- .github/workflows/prophunter.yml

Aktive Quellen:
- MLB: MLB StatsAPI + pybaseball/Statcast vorbereitet
- NBA: nba_api
- WNBA: ESPN/wehoop-style vorbereitet
- NFL: nflreadpy/nflverse-data
- vorbereitet: KBO, NPB, CPBL, EuroLeague, NCAAF, CFL, ELF

Reihenfolge:
1. prop_hunter_database_v10.sql ausführen, falls noch nicht gemacht.
2. prop_hunter_database_final.sql in Supabase ausführen.
3. Dateien ins Repo hochladen/ersetzen.
4. Workflow manuell starten mit run_backfill=true.
