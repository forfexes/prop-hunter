PROP HUNTER FINAL COVERAGE — ALL CURRENT FILES
==============================================

Dieses Paket enthält:
- alle aktuellen Prop-Hunter-Dateien aus der letzten Final Edition
- zusätzliche Player-Props-Odds-Connectoren
- Results-Scraper für NBA/WNBA/NFL/MLB
- Settlement Engine
- Learning Update
- Statcast/Retrosheet/NCAAF vorbereitete Backfills
- neue SQL und Workflow

Neue wichtige Dateien:
- prop_hunter_shared_utils.py
- prop_hunter_odds_oddsapi_io.py
- prop_hunter_odds_sportsgameodds.py
- prop_hunter_odds_opticodds.py
- prop_hunter_results_nba.py
- prop_hunter_results_wnba.py
- prop_hunter_results_nfl.py
- prop_hunter_results_mlb.py
- prop_hunter_statcast_backfill.py
- prop_hunter_settler.py
- prop_hunter_learning_update.py
- espn_multisport_results.py
- prop_hunter_backfill_ncaaf.py
- prop_hunter_retrosheet_import.py
- prop_hunter_database_final_coverage.sql

Reihenfolge:
1. prop_hunter_database_v10.sql ausführen, falls noch nicht gemacht.
2. prop_hunter_database_final.sql ausführen, falls vorhanden.
3. prop_hunter_database_final_coverage.sql ausführen.
4. Alle Dateien ins GitHub Repo hochladen/ersetzen.
5. .github/workflows/prophunter.yml ersetzen.
6. Workflow manuell starten:
   - run_extra_odds = true
   - run_backfill = true

Secrets optional für neue Quellen:
- ODDSAPI_IO_KEY oder ODDS_API_IO_KEY
- SPORTSGAMEODDS_API_KEY
- OPTICODDS_API_KEY
- CFBD_API_KEY

Ohne diese Keys laufen die Dateien sicher weiter und überspringen die jeweilige Quelle.
