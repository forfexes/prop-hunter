PROP HUNTER V10 LEARNING MACHINE
================================

Ziel:
- International: Baseball, Basketball, American Football
- MLB/NBA/WNBA/NFL zuerst
- KBO/NPB/CPBL/EuroLeague/NCAAF/CFL/ELF vorbereitet
- Learning Machine mit Last 20/30 Gamelogs
- market-spezifische 1-5 Leg Builder
- Cross-Sport Builder: HR + TD + Double-Double + RBA/PRA usw.

Dateien:
- prop_hunter_database_v10.sql
- prop_hunter_league_config.py
- prop_hunter_rules.py
- prop_hunter_leg_builder.py
- prop_hunter_learning.py
- prop_hunter_history_scraper.py
- requirements.txt
- .github/workflows/prophunter.yml

Reihenfolge:
1. SQL in Supabase ausführen
2. Dateien ins Repo hochladen/ersetzen
3. Workflow starten
4. Log prüfen:
   PROP HUNTER V10 HISTORY SCRAPER
   MLB history fetched
   DATA+ enrichment applied
   Telegram OK

Wichtig:
Das ist der Unterbau. Danach integrieren wir rules + leg_builder direkt in prophunter.py.
