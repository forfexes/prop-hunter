
-- PROP HUNTER LEARNING MACHINE V10
-- =================================
-- Alle Tabellen mit prop_hunter_* Prefix.
-- Sicher neben Netrattler / Prop Builder.

create table if not exists prop_hunter_leagues (
  id bigserial primary key,
  sport text not null,
  league text not null,
  country text,
  season text,
  source text,
  enabled boolean default true,
  priority int default 100,
  props_enabled boolean default true,
  history_enabled boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (sport, league, coalesce(season,''), coalesce(source,''))
);

create table if not exists prop_hunter_players (
  id bigserial primary key,
  sport text not null,
  league text,
  country text,
  source text,
  source_player_id text,
  player_name text not null,
  normalized_name text not null,
  team text,
  position text,
  handedness text,
  height text,
  weight text,
  birthdate date,
  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (sport, league, source, source_player_id)
);

create index if not exists idx_ph_players_name
  on prop_hunter_players(sport, league, normalized_name);

create table if not exists prop_hunter_teams (
  id bigserial primary key,
  sport text not null,
  league text,
  country text,
  source text,
  source_team_id text,
  team_name text not null,
  abbreviation text,
  normalized_team text,
  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (sport, league, source, source_team_id)
);

create table if not exists prop_hunter_games (
  id bigserial primary key,
  sport text not null,
  league text,
  country text,
  season text,
  source text,
  source_game_id text,
  game_date timestamptz,
  home_team text,
  away_team text,
  status text,
  venue text,
  weather jsonb default '{}'::jsonb,
  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (sport, league, source, source_game_id)
);

create table if not exists prop_hunter_player_gamelogs (
  id bigserial primary key,
  sport text not null,
  league text,
  country text,
  season text,
  source text,
  source_game_id text,
  game_id text,
  game_date date,
  player_name text not null,
  normalized_name text not null,
  team text,
  opponent text,
  home_away text,
  position text,

  minutes numeric,
  points numeric,
  rebounds numeric,
  assists numeric,
  pra numeric,
  ra numeric,
  threes_made numeric,
  steals numeric,
  blocks numeric,
  turnovers numeric,
  double_double boolean,
  triple_double boolean,

  hits numeric,
  total_bases numeric,
  home_runs numeric,
  rbi numeric,
  runs numeric,
  strikeouts_batter numeric,
  walks_batter numeric,
  stolen_bases numeric,

  pitcher_strikeouts numeric,
  pitcher_innings numeric,
  pitcher_hits_allowed numeric,
  pitcher_earned_runs numeric,
  pitcher_walks numeric,
  pitcher_home_runs_allowed numeric,
  pitcher_outs numeric,

  receptions numeric,
  receiving_yards numeric,
  rushing_yards numeric,
  rush_attempts numeric,
  passing_yards numeric,
  passing_tds numeric,
  interceptions numeric,
  touchdowns numeric,
  red_zone_targets numeric,
  goal_line_carries numeric,
  snaps numeric,
  routes numeric,
  targets numeric,

  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),

  unique (sport, league, season, game_id, normalized_name)
);

create index if not exists idx_ph_gamelogs_player
  on prop_hunter_player_gamelogs(sport, league, normalized_name, game_date desc);
create index if not exists idx_ph_gamelogs_market
  on prop_hunter_player_gamelogs(sport, league, game_date desc);
create index if not exists idx_ph_gamelogs_raw
  on prop_hunter_player_gamelogs using gin(raw);

create table if not exists prop_hunter_prop_snapshots (
  id bigserial primary key,
  snapshot_ts timestamptz default now(),
  run_id text,
  sport text not null,
  league text,
  country text,
  event_id text,
  game_date date,
  game text,
  player_name text not null,
  normalized_name text not null,
  team text,
  opponent text,
  market text not null,
  market_group text,
  direction text,
  line numeric,
  odds numeric,
  bookmaker text,
  implied_prob numeric,
  fair_prob numeric,
  edge_pct numeric,
  source text,
  source_confidence numeric,
  raw jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);

create index if not exists idx_ph_prop_snapshots_player
  on prop_hunter_prop_snapshots(sport, league, normalized_name, snapshot_ts desc);
create index if not exists idx_ph_prop_snapshots_market
  on prop_hunter_prop_snapshots(sport, league, market_group, snapshot_ts desc);

create table if not exists prop_hunter_candidates (
  id bigserial primary key,
  run_id text,
  created_at timestamptz default now(),
  sport text,
  league text,
  country text,
  player_name text,
  normalized_name text,
  team text,
  game text,
  market text,
  market_group text,
  direction text,
  line numeric,
  odds numeric,
  probability numeric,
  edge_pct numeric,
  category text,
  rule_id text,
  leg_type text,
  risk_level text,
  confidence numeric,
  reasons jsonb default '[]'::jsonb,
  features jsonb default '{}'::jsonb,
  passed boolean default false,
  reject_reason text
);

create index if not exists idx_ph_candidates_run
  on prop_hunter_candidates(run_id, passed);
create index if not exists idx_ph_candidates_rule
  on prop_hunter_candidates(rule_id, created_at desc);

create table if not exists prop_hunter_picks (
  id bigserial primary key,
  pick_id text unique,
  run_id text,
  posted_at timestamptz default now(),
  sport text,
  league text,
  country text,
  category text,
  leg_count int default 1,
  builder_type text,
  player_name text,
  normalized_name text,
  team text,
  game text,
  market text,
  market_group text,
  direction text,
  line numeric,
  odds numeric,
  stake numeric,
  probability numeric,
  edge_pct numeric,
  confidence numeric,
  rule_id text,
  legs jsonb default '[]'::jsonb,
  features jsonb default '{}'::jsonb,
  telegram_text text,
  status text default 'open'
);

create index if not exists idx_ph_picks_open
  on prop_hunter_picks(status, posted_at desc);
create index if not exists idx_ph_picks_rule
  on prop_hunter_picks(rule_id, posted_at desc);

create table if not exists prop_hunter_results (
  id bigserial primary key,
  pick_id text references prop_hunter_picks(pick_id) on delete cascade,
  settled_at timestamptz default now(),
  result text check (result in ('win','loss','push','void')),
  final_value numeric,
  closing_line numeric,
  closing_odds numeric,
  profit_units numeric,
  raw jsonb default '{}'::jsonb
);

create table if not exists prop_hunter_rule_performance (
  id bigserial primary key,
  rule_id text not null unique,
  sport text,
  league text,
  market_group text,
  category text,
  sample_size int default 0,
  wins int default 0,
  losses int default 0,
  pushes int default 0,
  profit_units numeric default 0,
  roi numeric default 0,
  hit_rate numeric default 0,
  avg_clv numeric default 0,
  learned_weight numeric default 1.0,
  updated_at timestamptz default now()
);

create table if not exists prop_hunter_source_snapshots (
  id bigserial primary key,
  source_key text,
  section text,
  entity_key text,
  payload jsonb default '{}'::jsonb,
  updated_at timestamptz default now(),
  unique(source_key, section, entity_key)
);

alter table prop_hunter_leagues disable row level security;
alter table prop_hunter_players disable row level security;
alter table prop_hunter_teams disable row level security;
alter table prop_hunter_games disable row level security;
alter table prop_hunter_player_gamelogs disable row level security;
alter table prop_hunter_prop_snapshots disable row level security;
alter table prop_hunter_candidates disable row level security;
alter table prop_hunter_picks disable row level security;
alter table prop_hunter_results disable row level security;
alter table prop_hunter_rule_performance disable row level security;
alter table prop_hunter_source_snapshots disable row level security;

insert into prop_hunter_leagues (sport, league, country, source, priority)
values
('BASEBALL','MLB','USA','mlb_statsapi',1),
('BASEBALL','KBO','Korea','api_or_scrape',2),
('BASEBALL','NPB','Japan','api_or_scrape',3),
('BASEBALL','CPBL','Taiwan','api_or_scrape',4),
('BASKETBALL','NBA','USA','nba_api_espn',1),
('BASKETBALL','WNBA','USA','espn_nba_stats',2),
('BASKETBALL','EUROLEAGUE','Europe','api_or_scrape',3),
('BASKETBALL','ACB','Spain','api_or_scrape',4),
('BASKETBALL','EUROCUP','Europe','api_or_scrape',5),
('BASKETBALL','NBL','Australia','api_or_scrape',6),
('AMERICAN_FOOTBALL','NFL','USA','nflverse_espn',1),
('AMERICAN_FOOTBALL','NCAAF','USA','api_or_scrape',2),
('AMERICAN_FOOTBALL','CFL','Canada','api_or_scrape',3),
('AMERICAN_FOOTBALL','UFL','USA','api_or_scrape',4),
('AMERICAN_FOOTBALL','ELF','Europe','api_or_scrape',5)
on conflict do nothing;
