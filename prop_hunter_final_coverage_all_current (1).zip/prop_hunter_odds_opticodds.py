#!/usr/bin/env python3
"""
PROP HUNTER — OPTICODDS CONNECTOR
=================================

Env:
OPTICODDS_API_KEY

Normalisiert Player Props und schreibt prop_hunter_prop_snapshots.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

from prop_hunter_shared_utils import (
    http_json, upsert_rows, safe_json_write, hash_key, now_iso, log, warn,
    norm_name, norm_market, to_float, american_to_decimal
)

BASE = os.getenv("OPTICODDS_BASE", "https://api.opticodds.com/api/v3").rstrip("/")
OUT = "prop_hunter_opticodds_props.json"

LEAGUES = {
    "MLB": "MLB",
    "NBA": "NBA",
    "WNBA": "WNBA",
    "NFL": "NFL",
    "NCAAF": "NCAAF",
}

def key():
    return os.getenv("OPTICODDS_API_KEY", "").strip()

def headers():
    return {"X-Api-Key": key()} if key() else {}

def extract_items(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for k in ("data", "events", "odds", "markets", "response"):
            if isinstance(data.get(k), list):
                return data[k]
    return []

def normalize(item: Dict[str, Any], sport: str, league: str) -> List[Dict[str, Any]]:
    rows = []
    event_id = str(item.get("id") or item.get("event_id") or item.get("game_id") or item.get("fixture_id") or "")
    home = item.get("home_team") or item.get("home")
    away = item.get("away_team") or item.get("away")
    commence = item.get("start_date") or item.get("commence_time") or item.get("start_time")
    player = item.get("player") or item.get("player_name") or item.get("participant") or item.get("selection")
    market = item.get("market") or item.get("market_name") or item.get("name")
    if player and market:
        line = item.get("line") or item.get("points") or item.get("handicap")
        odds = item.get("price") or item.get("odds") or item.get("decimal")
        rows.append({
            "snapshot_id": hash_key("opticodds", sport, event_id, player, market, line, odds),
            "source": "opticodds",
            "sport": sport,
            "league": league,
            "source_sport_key": league,
            "source_event_id": event_id,
            "game_id": event_id,
            "commence_time": commence,
            "home_team": home,
            "away_team": away,
            "player_name": player,
            "normalized_name": norm_name(player),
            "market": market,
            "market_key": norm_market(market),
            "line": to_float(line),
            "odds_decimal": to_float(odds) or american_to_decimal(odds),
            "bookmaker": item.get("sportsbook") or item.get("book") or item.get("bookmaker"),
            "raw": item,
            "created_at": now_iso(),
        })
        return rows

    for game in item.get("games", []) or []:
        rows.extend(normalize(game, sport, league))

    for book in item.get("sportsbooks", []) or item.get("bookmakers", []) or []:
        book_name = book.get("name") or book.get("id")
        for m in book.get("markets", []) or []:
            mname = m.get("name") or m.get("key")
            for sel in m.get("selections", []) or m.get("outcomes", []) or []:
                p = sel.get("player") or sel.get("name") or sel.get("participant")
                if not p:
                    continue
                line = sel.get("line") or sel.get("points")
                odds = sel.get("price") or sel.get("odds")
                rows.append({
                    "snapshot_id": hash_key("opticodds", sport, event_id, p, mname, line, odds, book_name),
                    "source": "opticodds",
                    "sport": sport,
                    "league": league,
                    "source_sport_key": league,
                    "source_event_id": event_id,
                    "game_id": event_id,
                    "commence_time": commence,
                    "home_team": home,
                    "away_team": away,
                    "player_name": p,
                    "normalized_name": norm_name(p),
                    "market": mname,
                    "market_key": norm_market(mname),
                    "line": to_float(line),
                    "odds_decimal": to_float(odds) or american_to_decimal(odds),
                    "bookmaker": book_name,
                    "raw": sel,
                    "created_at": now_iso(),
                })
    return rows

def fetch_sport(sport: str) -> List[Dict[str, Any]]:
    if not key():
        warn("OPTICODDS_API_KEY missing")
        return []
    league = LEAGUES.get(sport, sport)
    rows = []
    paths = [
        f"{BASE}/fixtures/odds",
        f"{BASE}/odds",
        f"{BASE}/fixtures",
        f"{BASE}/player-props",
    ]
    params = {"league": league, "is_main": "false", "market": "player"}
    for url in paths:
        data = http_json(url, params=params, headers=headers(), retries=1)
        items = extract_items(data)
        if items:
            for it in items:
                if isinstance(it, dict):
                    rows.extend(normalize(it, sport, league))
            log(f"opticodds {sport}: {len(rows)} props from {url}")
            return rows
    return rows

def main():
    rows = []
    for sport in os.getenv("PROP_HUNTER_SPORTS", "MLB,NBA,WNBA,NFL").split(","):
        sport = sport.strip().upper()
        if sport:
            rows.extend(fetch_sport(sport))
    safe_json_write(OUT, rows)
    upsert_rows("prop_hunter_prop_snapshots", rows, "snapshot_id")
    log(f"opticodds done: {len(rows)} props")

if __name__ == "__main__":
    main()
