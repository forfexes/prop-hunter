#!/usr/bin/env python3
"""Generate 52 real editable PROP-HUNTER NBA master templates.

The photographic arena is a separate original, player-free artwork.
Every changing item is a named SVG data-field or data-image-slot.
No overpainting of old card screenshots, no prefilled bookmaker prices.
"""
from __future__ import annotations
import base64, io, json, math, os, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from PIL import Image, ImageDraw, ImageFont
import cairosvg

HERE=Path(__file__).resolve().parent
W,H=1080,1440
GOLD='#FFD66B'; BLUE='#35C9FF'; GREEN='#2CFF8E'; PURPLE='#D83AFF'; WHITE='#F5F7FF'; MUTED='#A9C9DE'; DARK='#04101F'

MARKETS={
'single':'PRO TIP · SINGLE','points':'POINTS','rebounds':'REBOUNDS','assists':'ASSISTS',
 'threes':'3-POINTER','pra':'PTS + REB + AST','points_rebounds':'PTS + REB',
 'points_assists':'PTS + AST','rebounds_assists':'REB + AST','steals':'STEALS',
 'blocks':'BLOCKS','stocks':'STEALS + BLOCKS','double_double':'DOUBLE-DOUBLE',
 'triple_double':'TRIPLE-DOUBLE','turnovers':'TURNOVERS','fouls':'FOULS',
 'first_basket':'FIRST BASKET','team_total':'TEAM TOTAL','match_total':'MATCH TOTAL',
 'moneyline':'MONEYLINE','spread':'SPREAD'
}
FAMILIES={'ladder':'NBA LADDER','builder':'NBA PROP BUILDER','same_player':'SAME PLAYER BUILDER',
          'cross_game':'CROSS GAME BUILDER','combo':'NBA COMBO / MULTI','lottery':'NBA LOTTERY'}


def esc(v):
    return str(v).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')

def rect(x,y,w,h,rad=20,fill='url(#panel)',stroke=BLUE,sw=2,opacity=1):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rad}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" opacity="{opacity}"/>'

def txt(x,y,s,size=28,color=WHITE,anchor='start',field=None,italic=False,weight=800):
    return (f'<text x="{x}" y="{y}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" '
            f'font-weight="{weight}" font-style="{"italic" if italic else "normal"}" '
            f'text-anchor="{anchor}" fill="{color}"'+(f' data-field="{field}"' if field else '')+
            f'>{esc(s)}</text>')

def dynamic(x,y,key,size=30,color=WHITE,anchor='start',italic=False,max_width=None):
    node=txt(x,y,'',size,color,anchor,field=key,italic=italic)
    if max_width is not None:
        node=node.replace(' data-field=',f' data-max-width="{max_width}" data-field=',1)
    return node

def gold_line(x1,y1,x2,y2):
    return f'<path d="M{x1} {y1} L{x2} {y2}" stroke="{GOLD}" stroke-width="2" opacity=".7"/>'

def neon_box(x,y,w,h,color=BLUE,rad=20,fill='url(#panel)'):
    return (rect(x-2,y-2,w+4,h+4,rad+2,'none',color,8,.11)+
            rect(x,y,w,h,rad,fill,color,2.7)+
            f'<path d="M{x+20} {y+3} H{x+w-20}" stroke="white" stroke-opacity=".62" stroke-width="2"/>')

def asset_slot(key,x,y,w,h):
    return f'<g id="slot-{key}" data-image-slot="{key}" data-x="{x}" data-y="{y}" data-width="{w}" data-height="{h}" data-frameless="true"/>'

def svg_start(height=H):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 {W} {height}" width="{W}" height="{height}">
<title>PROP HUNTER NBA premium layered master</title>
<defs>
<linearGradient id="panel" x2="0" y2="1"><stop stop-color="#143B64" stop-opacity=".96"/><stop offset=".24" stop-color="#07172E" stop-opacity=".95"/><stop offset="1" stop-color="#020A17" stop-opacity=".98"/></linearGradient>
<linearGradient id="gold" x2=".2" y2="1"><stop stop-color="#FFF9CD"/><stop offset=".24" stop-color="#FFE585"/><stop offset=".53" stop-color="#E5A831"/><stop offset=".75" stop-color="#FFF0A6"/><stop offset="1" stop-color="#A86C14"/></linearGradient>
<linearGradient id="metal" x2="0" y2="1"><stop stop-color="#FFFFFF"/><stop offset=".36" stop-color="#F9FCFF"/><stop offset=".54" stop-color="#C5D3E3"/><stop offset=".77" stop-color="#FFFFFF"/><stop offset="1" stop-color="#65758A"/></linearGradient>
<linearGradient id="green" x2="0" y2="1"><stop stop-color="#114D37"/><stop offset=".4" stop-color="#031D15"/><stop offset="1" stop-color="#020F0B"/></linearGradient>
<linearGradient id="amber" x2="0" y2="1"><stop stop-color="#765012"/><stop offset=".4" stop-color="#2A1703"/><stop offset="1" stop-color="#080E16"/></linearGradient>
<linearGradient id="purple" x2="0" y2="1"><stop stop-color="#681580"/><stop offset=".4" stop-color="#250634"/><stop offset="1" stop-color="#0E0924"/></linearGradient>
<linearGradient id="glass" x2="0" y2="1"><stop stop-color="#0D2C4B" stop-opacity=".35"/><stop offset="1" stop-color="#030C19" stop-opacity=".85"/></linearGradient>
</defs>
<g id="layer-01-arena-photo" data-static-background="true"><image x="0" y="0" width="1080" height="{height}" preserveAspectRatio="xMidYMid slice" xlink:href="assets/arena.jpg"/></g>
<g id="layer-02-arena-vignette">{rect(0,0,W,height,0,'#000A18','none',0,.23)}
<path d="M0 1000 H1080 V1250 H0Z" fill="#001328" opacity=".27"/></g>
'''

def header(label,small='NBA',accent=GOLD):
    return f'''<g id="layer-03-branding">
<path d="M498 64 L510 23 L540 45 L570 23 L582 64Z" fill="url(#gold)" stroke="#FFF0A0" stroke-width="3"/>
<circle cx="540" cy="105" r="58" stroke="#E9B53C" stroke-width="4" fill="none" opacity=".65"/>
{txt(540,136,'PROP-HUNTER',69,'#031020','middle',italic=True)}
<text x="540" y="130" font-family="DejaVu Sans,Arial,sans-serif" font-size="69" font-weight="900" font-style="italic" text-anchor="middle" fill="url(#metal)" stroke="#E1A12C" stroke-width="1.8" paint-order="stroke">PROP-HUNTER</text>
<path d="M330 147 H750" stroke="#F3C25E" stroke-width="3" opacity=".9"/>
{neon_box(38,38,115,121,GOLD,16)}<image x="69" y="40" width="54" height="116" preserveAspectRatio="xMidYMid meet" xlink:href="assets/nba_logo.png" data-static-nba-logo="true"/>
{neon_box(231,164,618,76,accent,16,'url(#purple)' if accent==PURPLE else 'url(#amber)')}{txt(540,217,label,30 if len(label)>22 else 36,'#FFE7FF' if accent==PURPLE else 'url(#gold)','middle',italic=True)}
</g>'''

def crest_pair(y=275,mini=False):
    """No crest frame; home/away names are editable text directly below logos."""
    size=100 if mini else 125
    x1,x2=(397,645) if not mini else (401,617)
    mid=(x1+x2+size)//2
    return f'''<g id="layer-05-floating-team-crests">
{asset_slot('home_logo',x1,y,size,size)}
{asset_slot('away_logo',x2,y,size,size)}
{txt(580,y+size*.64,'VS',54 if not mini else 46,'url(#gold)','middle',italic=True)}
{dynamic(x1+size/2,y+size+38,'home_name',22,WHITE,'middle',True)}
{dynamic(x2+size/2,y+size+38,'away_name',22,WHITE,'middle',True)}
</g>'''

def match_info(x=837,y=305):
    return f'''<g id="layer-06-match-metadata">
{txt(x,y,'DATUM',18,GOLD)}{dynamic(x,y+36,'date',22)}{gold_line(x,y+48,1050,y+48)}
{txt(x,y+92,'UHRZEIT',18,GOLD)}{dynamic(x,y+129,'time',22)}{gold_line(x,y+141,1050,y+141)}
{txt(x,y+184,'ARENA',18,GOLD)}{dynamic(x,y+220,'venue',19,max_width=1050-x)}
</g>'''

def settlement(y=1260,accent=GOLD):
    return f'''<g id="layer-12-settlement">
{neon_box(39,y,765,95,accent,12,'url(#purple)' if accent==PURPLE else 'url(#amber)')}
{txt(66,y+60,'◎ AUSWERTUNG:',34,WHITE,italic=True)}
{dynamic(540,y+60,'settlement',32,GOLD,'middle',True)}
{txt(1038,y+134,'@prophunter',28,WHITE,'end',italic=True)}
</g>'''

def stats(y=833,for_ladder=False):
    s=f'<g id="layer-10-last-games-model-stake">'
    for x,w,title in ((24,377,'LETZTE SPIELE'),(417,375,'MODELL'),(809,247,'EINSATZ')):
        s+=neon_box(x,y,w,300,BLUE,22)+rect(x+7,y+7,w-14,60,14,'#062C4B','none',0,.75)
        s+=txt(x+20,y+49,title,27,WHITE,italic=True)
    for i,key in enumerate(('l5','l10','l15')):
        yy=y+120+i*68
        s+=rect(45,yy-34,335,54,24,'#071A30','#8AAFD3',1.6,.8)
        s+=txt(72,yy,key.upper(),31,WHITE,italic=True)
        s+=dynamic(356,yy,key,31,GOLD,'end',True)
    for i,key in enumerate(('prob','edge','conf')):
        yy=y+120+i*68
        s+=rect(438,yy-34,336,54,24,'#071A30','#8AAFD3',1.6,.8)
        s+=txt(455,yy,key.upper(),27,WHITE,italic=True)
        s+=dynamic(757,yy,key,29,GOLD,'end',True)
    s+=neon_box(827,y+103,210,155,GOLD,20,'url(#amber)')
    s+=dynamic(932,y+207,'stake',62,GOLD,'middle',True)
    return s+'</g>'

def single(label):
    s=svg_start()+header('PRO TIP — SINGLE')
    s+=f'<g id="layer-04-frameless-athlete">{asset_slot("player_photo",-20,180,300,615)}</g>'
    s+=crest_pair(286)+match_info(838,286)
    s+=f'<g id="layer-07-player-name">{dynamic(580,550,"player_name",40,WHITE,"middle",True,max_width=420)}</g>'
    # The generic Single already has the exact PRO TIP — SINGLE header.
    # Never repeat PRO TIP below the player name; leave that area clear.
    if label != 'PRO TIP · SINGLE':
        s+=f'<g id="layer-07-market-title">{txt(569,605,label,37,WHITE,"middle",italic=True)}</g>'
    s+=f'<g id="layer-08-bet-market">{neon_box(303,639,531,112,GREEN,22,"url(#green)")}'
    s+=dynamic(566,709,'market',43,WHITE,'middle',True)
    s+=neon_box(850,639,202,112,GOLD,20,'url(#amber)')+dynamic(951,710,'odds',43,GOLD,'middle',True)+'</g>'
    s+=stats(801)+settlement(1228)+'</svg>'
    return s

def leg_row(x,y,w,h,i,family):
    # All leg-specific elements are independent; no baked players or sample odds.
    is_ladder=family in ('ladder','same_player')
    c=GREEN if is_ladder else PURPLE if family=='lottery' else BLUE
    s=f'<g id="layer-leg-{i}">'+neon_box(x,y,w,h,c,14)
    s+=rect(x+12,y+14,85,h-28,10,'url(#gold)','none',0,1)
    s+=txt(x+55,y+h/2+10,f'{i}.',30,'#071226','middle',italic=True)
    if not is_ladder and family in ('builder','cross_game','lottery'):
        s+=asset_slot(f'leg_{i}_photo',x+103,y+4,round(min(h*.86,92)),h-8)
        left=x+215
    else:
        left=x+118
    text_width=x+w-200-left
    if is_ladder:
        # One market label per rung; use the second line for that rung's
        # own observed recent form rather than repeating the same selection.
        s+=dynamic(left,y+h*.39,f'leg_{i}_line',25,WHITE,max_width=text_width)
        s+=dynamic(left,y+h*.76,f'leg_{i}_form',16,MUTED,max_width=text_width)
    else:
        # All legs have their own form; never reuse the parent selection's hit rate.
        # Reserve distinct baselines even in the longest tickets.
        if family in ('lottery','combo','cross_game'):
            s+=dynamic(left,y+h*.20,f'leg_{i}_name',min(26,int(h*.20)),WHITE,max_width=text_width)
            s+=dynamic(left,y+h*.45,f'leg_{i}_market',min(24,int(h*.19)),GOLD,max_width=text_width)
            s+=dynamic(left,y+h*.66,f'leg_{i}_game',min(18,int(h*.17)),MUTED,max_width=text_width)
            s+=dynamic(left,y+h*.87,f'leg_{i}_form',min(18,int(h*.16)),GREEN,max_width=text_width)
        else:
            s+=dynamic(left,y+h*.29,f'leg_{i}_name',min(26,int(h*.25)),WHITE,max_width=text_width)
            s+=dynamic(left,y+h*.58,f'leg_{i}_market',min(24,int(h*.23)),GOLD,max_width=text_width)
            s+=dynamic(left,y+h*.86,f'leg_{i}_form',min(18,int(h*.19)),GREEN,max_width=text_width)
    s+=neon_box(x+w-186,y+h/2-32,166,64,GOLD,14,'url(#amber)')
    s+=dynamic(x+w-103,y+h/2+10,f'leg_{i}_odds',27,GOLD,'middle',True)
    s+='</g>'
    return s

def builder_hero(n):
    """Owner-original 2/3-player Builder hierarchy: large borderless athletes.

    The supplied screenshot has three prominent portraits across the arena,
    verified form panels, fixture crests, a total quote and leg-detail list.
    Every image/text value remains an independent editable SVG field.
    """
    if n not in (2, 3):
        raise ValueError("Hero Builder requires two or three verified athletes")
    s=svg_start()+header("PRO TIP — BUILDER")
    centers=(330,750) if n==2 else (200,540,880)
    s+='<g id="layer-04-original-builder-hero-portraits">'
    for i,cx in enumerate(centers,1):
        left=cx-144
        s+=asset_slot(f'leg_{i}_photo',left,246,288,325)
        s+=neon_box(left-9,574,306,85,GOLD,14)
        # Keep the name and market once, in the corresponding numbered ticket.
        # The portrait is identified by the matching number, not duplicate text.
        s+=txt(cx,630,f'{i}.',31,GOLD,'middle',italic=True)
        s+=neon_box(left,661,288,61,BLUE,12)
        for index,form in enumerate(('l5','l10','l15')):
            xx=left+12+index*93
            s+=txt(xx,685,form.upper(),16,GOLD)
            s+=dynamic(xx,711,f'leg_{i}_{form}',21,GREEN)
    s+='</g>'
    s+=crest_pair(760,mini=True)+match_info(845,734)
    s+='<g id="layer-08-original-builder-ticket">'
    s+=neon_box(34,981,1012,78,GOLD,17,'url(#amber)')
    s+=txt(63,1031,f'{n}-LEG BUILDER',37,WHITE,italic=True)
    s+=txt(538,1008,'GESAMTQUOTE',18,GOLD)
    s+=dynamic(740,1041,'total_odds',31,GOLD,'end',True)
    s+=txt(852,1008,'EINSATZ',18,WHITE)
    s+=dynamic(1013,1041,'stake',31,GOLD,'end',True)
    for i in range(1,n+1):
        y=1066+(i-1)*(152/n)
        s+=neon_box(43,y,993,round(140/n),BLUE,10)
        s+=txt(70,y+round(100/n),str(i)+'.',25,GOLD,italic=True)
        s+=dynamic(125,y+round(100/n),f'leg_{i}_name',22,WHITE)
        s+=dynamic(492,y+round(100/n),f'leg_{i}_market',21,GOLD)
        s+=dynamic(999,y+round(100/n),f'leg_{i}_odds',24,GOLD,'end',True)
    s+='</g>'
    s+=settlement(1240)+'</svg>'
    return s


def multi(family,n):
    if family == 'builder' and n in (2,3):
        return builder_hero(n)
    # Existing 2-6 masters remain pixel-identical. Longer originals-inspired
    # cards preserve the premium arena and artwork but extend rows/footer.
    if family == 'builder' and not 2 <= n <= 7:
        raise ValueError('Builder only supports 2-7 legs')
    if family in ('lottery','combo','cross_game') and not 2 <= n <= 12:
        raise ValueError('Multi-game tickets only support 2-12 legs')
    extra = max(0, n-6) * (105 if family in ('lottery','combo','cross_game') else 102)
    accent=PURPLE if family=='lottery' else GOLD
    s=svg_start(H+extra)+header(f'{FAMILIES[family]} · {n} LEGS',accent=accent)
    same=family in ('ladder','same_player')
    if same:
        s+=f'<g id="layer-04-frameless-athlete">{asset_slot("player_photo",-20,175,310,805)}</g>'
        s+=crest_pair(273,mini=True)+match_info(845,276)
        s+=f'<g id="layer-07-player-name">{dynamic(585,539,"player_name",40,WHITE,"middle",True,max_width=430)}</g>'
        x,w,top,bottom=298,750,566,1102
    elif family in ('lottery','combo','cross_game'):
        s+=f'<g id="layer-05-multi-game-context">{txt(540,325,"INDIVIDUELLE NBA-SPIELERPROPS",31,GOLD,"middle",italic=True)}{txt(540,373,"SPIELER · MARKT · SPIELZEIT · QUOTE",23,WHITE,"middle")}</g>'
        x,w,top,bottom=34,1012,(400 if n>=5 else 465),1099+extra
    else:
        s+=crest_pair(267,mini=True)+match_info(845,267)
        x,w,top,bottom=34,1012,510,1099+extra
    gap=12 if n>=5 else 16
    row_h=(bottom-top-gap*(n-1))/n
    s+='<g id="layer-08-legs">'
    for i in range(1,n+1):s+=leg_row(x,round(top+(i-1)*(row_h+gap)),w,round(row_h),i,family)
    s+='</g>'
    s+='<g id="layer-09-combination">'
    if family=='ladder':
        # Each rung has its own measured form. No empty or misleading aggregate boxes.
        s+=neon_box(726,1124+extra,320,97,GOLD,14,'url(#amber)')
        s+=txt(746,1186+extra,'EINSATZ',28,WHITE,italic=True)
        s+=dynamic(1022,1186+extra,'stake',34,GOLD,'end',True,max_width=134)
    else:
        s+=neon_box(35,1124+extra,675,97,GOLD,16,'url(#amber)')
        s+=txt(62,1186+extra,'GESAMTQUOTE',32,WHITE,italic=True)+dynamic(679,1186+extra,'total_odds',38,GOLD,'end',True)
        s+=neon_box(726,1124+extra,320,97,BLUE,16)
        s+=txt(746,1186+extra,'EINSATZ',28,WHITE,italic=True)+dynamic(1022,1186+extra,'stake',34,GOLD,'end',True)
    s+='</g>'
    s+=settlement(1240+extra,accent=accent)+'</svg>'
    return s


def build():
    (HERE/'assets').mkdir(exist_ok=True)
    if not (HERE/'assets'/'nba_logo.png').is_file():
        raise FileNotFoundError('Authentic user-supplied NBA logo asset missing')
    source_path=os.environ.get('PH_NBA_ARENA_SOURCE')
    src=Path(source_path) if source_path else None
    if (src is None or not src.is_file()) and not (HERE/'assets'/'arena.jpg').exists():
        raise FileNotFoundError('Original arena artwork must be supplied; do not substitute a screenshot with baked players')
    if src is not None and src.is_file():
        im=Image.open(src).convert('RGB').resize((W,H),Image.Resampling.LANCZOS)
        im.save(HERE/'assets'/'arena.jpg',quality=88,optimize=True,subsampling=0)
    templates={}
    for key,label in MARKETS.items():
        name=f'single_{key}'
        (HERE/f'{name}.svg').write_text(single(label),encoding='utf8')
        templates[name]={'family':'single','market':key,'legs':1,'file':f'{name}.svg'}
    (HERE/'longshot.svg').write_text(single('NBA LONGSHOT'),encoding='utf8')
    templates['longshot']={'family':'longshot','legs':1,'file':'longshot.svg'}
    for family in FAMILIES:
        for n in range(2,7):
            key=f'{family}_{n}'
            (HERE/f'{key}.svg').write_text(multi(family,n),encoding='utf8')
            templates[key]={'family':family,'legs':n,'file':f'{key}.svg'}
    manifest={'version':2,'format':'layered_svg','resolution':[W,H],'not_live':False,'production_gated':True,
              'template_count':len(templates),'templates':templates,
              'rules':{'photos':'transparent PNG cutouts only; no frames; independent layers',
                       'logos':'floating without frames, with dynamic team names beneath',
                       'ladder':'exactly one player portrait; 2-6 steps',
                       'same_player':'exactly one player portrait; 2-6 distinct prop legs',
                       'builder':'2-6 legs with independent photos and markets',
                       'odds':'only bookmaker-verified odds; no multiplication of independent legs',
                       'settlement':'edit original Telegram message only',
                       'background':'original player-free arena photo; never cover old example data',
                       'missing':'leave blank; never invent numbers'}}
    (HERE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return manifest


def _embed_arena(svg):
    image=base64.b64encode((HERE/'assets'/'arena.jpg').read_bytes()).decode('ascii')
    return (svg.replace('xlink:href="assets/arena.jpg"',f'xlink:href="data:image/jpeg;base64,{image}"')
               .replace('xlink:href="assets/nba_logo.png"',
                        'xlink:href="data:image/png;base64,'+base64.b64encode((HERE/'assets'/'nba_logo.png').read_bytes()).decode('ascii')+'"'))


def render_png(name,values=None,images=None):
    manifest=json.loads((HERE/'manifest.json').read_text())
    if name not in manifest['templates']:raise KeyError(name)
    root=ET.fromstring(_embed_arena((HERE/manifest['templates'][name]['file']).read_text()))
    for el in root.iter():
        key=el.get('data-field')
        if key is not None and values and key in values:
            el.text=str(values[key])
        slot=el.get('data-image-slot')
        if slot and images and slot in images:
            raw=images[slot]
            with Image.open(io.BytesIO(raw)) as im:
                if im.format!='PNG':raise ValueError(f'{slot} must be PNG')
                if (slot=='player_photo' or slot.endswith('_photo')) and im.convert('RGBA').getchannel('A').getextrema()[0]==255:
                    raise ValueError('Portrait must be a transparent cutout')
            sub=ET.SubElement(el,'{http://www.w3.org/2000/svg}image')
            sub.set('x',el.get('data-x'));sub.set('y',el.get('data-y'))
            sub.set('width',el.get('data-width'));sub.set('height',el.get('data-height'))
            sub.set('preserveAspectRatio','xMidYMax meet')
            sub.set('{http://www.w3.org/1999/xlink}href','data:image/png;base64,'+base64.b64encode(raw).decode('ascii'))
    return cairosvg.svg2png(bytestring=ET.tostring(root,encoding='utf-8'),output_width=W,output_height=H)


def qa_and_previews():
    manifest=json.loads((HERE/'manifest.json').read_text())
    assert len(manifest['templates'])==52
    for key,meta in manifest['templates'].items():
        root=ET.parse(HERE/meta['file']).getroot()
        fields={el.get('data-field') for el in root.iter() if el.get('data-field')}
        slots=[el.get('data-image-slot') for el in root.iter() if el.get('data-image-slot')]
        assert len(slots)==len(set(slots)),key
        assert {'settlement'}.issubset(fields),key
        assert not any('data:image' in str(el.attrib) for el in root.iter()),key
        if meta['family'] not in ('lottery','combo','cross_game'):
            assert 'home_logo' in slots and 'away_logo' in slots,key
        else:
            assert 'home_logo' not in slots and 'away_logo' not in slots,key
            assert f'leg_{meta["legs"]}_game' in fields,key
        if meta['family'] in ('single','longshot','ladder','same_player'):
            assert slots.count('player_photo')==1,key
        if meta['family'] in ('ladder','same_player'):
            assert sum(s.endswith('_photo') for s in slots)==1,key
        if meta['family'] in ('builder','cross_game','lottery'):
            assert sum(s.endswith('_photo') for s in slots)==meta['legs'],key
        if meta['legs']>1:
            assert ('total_odds' in fields) == (meta['family']!='ladder'),key
            assert 'stake' in fields,key
            last=meta["legs"]
            if meta['family'] in ('ladder','same_player'):
                assert {f'leg_{last}_line',f'leg_{last}_form'} <= fields,key
                assert f'leg_{last}_market' not in fields,key
            else:
                assert f'leg_{last}_market' in fields,key
    previews=HERE/'previews';previews.mkdir(exist_ok=True)
    for key in ('single_single','ladder_4','builder_4','builder_6','same_player_4','combo_5','lottery_6','longshot'):
        (previews/f'{key}.png').write_bytes(render_png(key))
    keys=['single_single','single_points','single_rebounds','single_assists','longshot',
          'ladder_2','ladder_4','ladder_6','builder_2','builder_4','builder_6',
          'same_player_4','cross_game_5','combo_5','lottery_6']
    cols=5;tw,th=250,334;pad=20;lab=38
    overview=Image.new('RGB',(cols*(tw+pad)+pad,3*(th+lab+pad)+pad),(3,10,23))
    draw=ImageDraw.Draw(overview)
    try:font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',16)
    except:font=ImageFont.load_default()
    for i,key in enumerate(keys):
        x=pad+(i%cols)*(tw+pad);y=pad+(i//cols)*(th+lab+pad)
        pic=Image.open(io.BytesIO(render_png(key))).convert('RGB').resize((tw,th),Image.Resampling.LANCZOS)
        overview.paste(pic,(x,y))
        draw.text((x+4,y+th+7),key.replace('_',' ').upper(),font=font,fill=(255,213,102))
    overview.save(previews/'collection.png',quality=94)
    (HERE/'README.md').write_text('''# PROP HUNTER — NBA Premium Mastervorlagen v2

52 echte, **datenfreie**, mehrschichtige SVG-Master im freigegebenen blau-goldenen Arena-Stil. Der NBA-Logo-Kasten bleibt erhalten, mit dem NBA-Logo aus der vom Nutzer gelieferten Originalkarte anstelle des Textplatzhalters „NBA PROPS“.

## Aufbau
- `assets/arena.jpg`: eigenständiger Basketballarena-Hintergrund **ohne** Spieler, Teamwappen, Quoten, Namen oder Statistiken.
- `single_*.svg` (21): Single-Märkte; `longshot.svg` (1).
- `ladder_2.svg` bis `ladder_6.svg` (5): **ein** freigestellter Spieler, mehrere Stufen.
- `same_player_2.svg` bis `_6.svg` (5): **ein** Spieler, 2–6 verschiedene Props.
- `builder_2.svg` bis `_6.svg` (5): 2–6 Spieler/Legs mit eigenen transparenten Fotoebenen.
- `cross_game_2.svg` bis `_6.svg` (5), `combo_2.svg` bis `_6.svg` (5), `lottery_2.svg` bis `_6.svg` (5).

Jedes dynamische Textfeld ist mit `data-field` markiert. Fotos/Wappen sind separate `data-image-slot`-Ebenen. **Keine** eingebrannten Namen, Fotos, Wappen, Quoten oder Statistiken; **keine** überklebten Beispielkarten. Wappen sind frei schwebend und Teamnamen stehen darunter. Spieler links ohne Rahmen. Spielername kleiner, ohne PRO-TIP-Kasten oder Trennlinie.

`previews/` enthält die gerenderten **leeren** Master, nicht reale Tipps. Produktiv ist der neue Renderer über `PH_NBA_PREMIUM_V2=1` nur für NBA-Tipps mit echten Fotos, Wappen, Spielzeiten und verifizierten Buchmacherquoten aktiviert. Bei fehlenden Daten bleibt der bisherige Renderer als sichere Rückfallebene. Beim Settlement wird die **ursprüngliche Telegram-Nachricht bearbeitet**, ohne zusätzliche Tippnachricht.

`build_masters.py` erzeugt die 52 SVGs und die Prüf-Vorschauen aus dem vorhandenen Arena-Bild. `manifest.json` definiert die Familien und Feldbelegungen.
''',encoding='utf8')
    with zipfile.ZipFile(HERE.parent/'PROP_HUNTER_NBA_Premium_Mastervorlagen_52.zip','w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in HERE.rglob('*'):
            if p.is_file() and p.name!='__pycache__' and 'preview_test' not in p.name:
                z.write(p,p.relative_to(HERE.parent))
    print('PASS 52/52; preview',previews/'collection.png', 'zip', HERE.parent/'PROP_HUNTER_NBA_Premium_Mastervorlagen_52.zip')

if __name__=='__main__':
    build();qa_and_previews()
